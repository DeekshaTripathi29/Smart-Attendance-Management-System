package com.example.smartattendance;

import java.util.ArrayList;

public class dbRollnumber {
    String rollnumber;
    int isPresent;
    dbRollnumber(String rollnumber, int isPresent){
        this.rollnumber = rollnumber;
        this.isPresent = isPresent;
    }
}
