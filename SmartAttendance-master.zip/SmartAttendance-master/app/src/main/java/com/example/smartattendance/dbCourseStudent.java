package com.example.smartattendance;

public class dbCourseStudent {
    String Course;
    String name;
    String Spreadsheetlink;
    dbCourseStudent(){
        this.Course = null;
        this.name = null;
        this.Spreadsheetlink = null;
    }
}
