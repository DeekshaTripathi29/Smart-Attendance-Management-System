# Smart Attendance
The Android app that implements Attendance system in a smart and fast way like never before. It has the potential to replace the slow and boring way of taking attendance on paper sheets. This app makes it easy for both Teachers and students and also saves a lot of time.


![Screenshots](https://user-images.githubusercontent.com/26673203/55113070-2b51a200-5104-11e9-8fd0-5388a41c56de.jpg) 
![Screenshots](https://user-images.githubusercontent.com/26673203/55113114-43292600-5104-11e9-8f0b-fcdfe11682ae.jpg)
![Screenshots](https://user-images.githubusercontent.com/26673203/55113203-7d92c300-5104-11e9-9d47-8cfc5daea11e.jpg)

Connect to your teacher via Bluetooth or WiFi and mark your attendance within seconds!

**Features**: The app is in it's initial stage, but it already has some cool features inside!

Add the Teaching/Enrolled courses

Take/Mark attendance via Bluetooth or WiFi

Upload Attendance to Google sheets(Teacher only :-P)

View Attendance in sheets

View the virtual Map of the class and the present students in each bench. Students beware of this feature, since you can get caught of proxies here xD

More features coming soon!


You can get the debug apk [here](https://drive.google.com/open?id=1BUHwSiV261p64QuIOvTyxCBagF4zgZKW).(Unreleased)

